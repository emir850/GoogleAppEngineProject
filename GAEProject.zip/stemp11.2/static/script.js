'use strict';

window.addEventListener('load', function () {
    document.getElementById('sign-out').onclick = function() {
        // signout firebase
        firebase.auth().signOut();
    };


    var uiConfig = {
        signInSuccessUrl: '/',  // redirect to /
        signInOptions: [
            //permit google authentication and email authentication
            firebase.auth.GoogleAuthProvider.PROVIDER_ID,
            firebase.auth.EmailAuthProvider.PROVIDER_ID
        ]
    };

    // javascript that will react to whenever the firebase authentication state changes
    firebase.auth().onAuthStateChanged(function(user) {
        // if user signed in or not
        if(user) {
            // if signed in display logout
            document.getElementById('sign-out').hidden = false;
            document.getElementById('login-info').hidden = false;

            // console for debugging
            console.log('Signed in as ${user.displayName} (${user.email})');

            // get token for user
            user.getIdToken().then(function(token) {
                document.cookie = "token=" + token + ";path=/";
            });
        } else {
            // user not signed in display UI
            var ui = new firebaseui.auth.AuthUI(firebase.auth());
            ui.start('#firebase-auth-container', uiConfig);

            // hiding login logout when logged in
            document.getElementById('sign-out').hidden = true;
            document.getElementById('login-info').hidden = true;
            document.cookie = "token=;path=/";
        }
    }, function(error) {
        console.log(error);
        alert('Unable to log in: ' + error);
    });
});
