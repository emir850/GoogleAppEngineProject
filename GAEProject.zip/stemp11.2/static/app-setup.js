var firebaseConfig = {
  apiKey: "AIzaSyB0sePiu7zn_4PxGsWQ36z--TYU3QR8ni0",
  authDomain: "assignment01esahin.firebaseapp.com",
  projectId: "assignment01esahin",
  storageBucket: "assignment01esahin.appspot.com",
  messagingSenderId: "898021535142",
  appId: "1:898021535142:web:e1f7d8225d2a76e6f27367"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
