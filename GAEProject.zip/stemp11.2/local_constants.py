PROJECT_NAME='assignment01esahin'
PROJECT_STORAGE_BUCKET='assignment01esahin.appspot.com'