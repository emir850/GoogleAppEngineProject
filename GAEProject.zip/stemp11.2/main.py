#imports
import datetime  # import datetime
import random  # random
import uuid  # importing uuid4 for key
import local_constants  # importing local_constants
from flask import Flask, Response, jsonify, redirect, render_template, request, url_for, abort  # importing Flask 
from google.cloud import datastore, storage  # import googlecloud
import google.oauth2.id_token  # import for google token
from google.auth.transport import requests  

app = Flask(__name__)

# Get access to the datastore o
datastore_client = datastore.Client()

# Get access to firebase 
firebase_request_adapter = requests.Request()

# Function for creating a user info entity in the datastore
def createUserInfo(claims):
    entity_key = datastore_client.key('UserInfo', claims['email'])
    entity = datastore.Entity(key = entity_key)
    entity.update({
        'email': claims['email'],
        'name': claims['name'],
    })
    datastore_client.put(entity)

# Function for retrieving user info from the datastore
def retrieveUserInfo(claims):
    entity_key = datastore_client.key('UserInfo', claims['email'])
    entity = datastore_client.get(entity_key)
    return entity

# Function for listing blobs in a Google Cloud Storage bucket with a given prefix
def blobList(prefix):
    storage_client = storage.Client(project=local_constants.PROJECT_NAME)
    return storage_client.list_blobs(local_constants.PROJECT_STORAGE_BUCKET,prefix=prefix)

# Blob downlaod function
def downloadBlob(filename):
    storage_client = storage.Client(project=local_constants.PROJECT_NAME)
    bucket = storage_client.bucket(local_constants.PROJECT_STORAGE_BUCKET)

    blob = bucket.blob(filename)
    return blob.download_as_bytes()

# File Add function
def addFile(file):
    storage_client = storage.Client(project=local_constants.PROJECT_NAME)
    bucket = storage_client.bucket(local_constants.PROJECT_STORAGE_BUCKET)

    blob = bucket.blob(file.filename)
    blob.upload_from_file(file)


# Add directory function with unique key system
def addDirectory(directory_name, claims):
    storage_client = storage.Client(project=local_constants.PROJECT_NAME)
    bucket = storage_client.bucket(local_constants.PROJECT_STORAGE_BUCKET)

    blob = bucket.blob(directory_name )
    blob.upload_from_string('', content_type='application/x-www-form-urlencoded;charset=UTF-8')

    id = random.getrandbits(63)
    directory_key = datastore_client.key('directory',directory_name)
    entity = datastore.Entity(key = directory_key)
    entity.update({
            'email': claims['email'],
            'date': datetime.datetime.now(),
            'directory_name':directory_name,
            'key': id,
    })
    datastore_client.put(entity)



# def getBloblist(directory):
#     storage_client = storage.Client(project=local_constants.PROJECT_NAME)
#     bucket = storage_client.bucket(local_constants.PROJECT_STORAGE_BUCKET)
 

# Route for display directory
@app.route('/directory/<string:directory_name>/')
def directory(directory_name):
    id_token = request.cookies.get("token")
    error_message = None
    claims = None
    times = None
    user_info = None
    file_list = []
    directory_list = []
    if id_token:
        try:
            claims = google.oauth2.id_token.verify_firebase_token(id_token,
            firebase_request_adapter)
            user_info = retrieveUserInfo(claims)
            if user_info == None:
                createUserInfo(claims)
                user_info = retrieveUserInfo(claims)
            blob_list = blobList(directory_name)
            for i in blob_list:
                if i.name[len(i.name) - 1] == '/':
                    directory_list.append(i)
                else:
                    file_list.append(i)
        except ValueError as exc:
            error_message = str(exc)
    return render_template('directory.html', user_data=claims, error_message=error_message,
user_info=user_info, file_list=file_list, directory_list=directory_list, directory_name=directory_name)


# Route for handling the addition of a directory
@app.route('/add_directory', methods=['POST'])
def addDirectoryHandler():
    print("started adding directory")
    id_token = request.cookies.get("token")
    error_message = None
    claims = None
    times = None
    user_info = None
    if id_token:
        try:
            claims = google.oauth2.id_token.verify_firebase_token(id_token,firebase_request_adapter)
            directory_name = request.form['dir_name']
            if directory_name == '' or directory_name[len(directory_name) - 1] != '/':
                return redirect('/')
            user_info = retrieveUserInfo(claims)
            addDirectory(directory_name,claims)
        except ValueError as exc:
            error_message = str(exc)
    print(directory_name)
    return redirect('/')

# Route for upload
@app.route('/upload_file', methods=['post'])
def uploadFileHandler():
    id_token = request.cookies.get("token")
    error_message = None
    claims = None
    times = None
    user_info = None
    if id_token:
        try:
            claims = google.oauth2.id_token.verify_firebase_token(id_token,
            firebase_request_adapter)
            file = request.files['file_name']
            if file.filename == '':
                return redirect('/')
            user_info = retrieveUserInfo(claims)
            addFile(file)
        except ValueError as exc:
            error_message = str(exc)
    return redirect('/')


@app.route('/upload_filedir', methods=['post'])
def uploadFileDirHandler():
    id_token = request.cookies.get("token")
    error_message = None
    claims = None
    times = None
    user_info = None
    if id_token:
        try:
            claims = google.oauth2.id_token.verify_firebase_token(id_token,
            firebase_request_adapter)
            file = request.files['file_name']
            directory_name = request.form['dir_name']
            if file.filename == '':
                return redirect('/')
            user_info = retrieveUserInfo(claims)
            storage_client = storage.Client(project=local_constants.PROJECT_NAME)
            bucket = storage_client.bucket(local_constants.PROJECT_STORAGE_BUCKET + '/' + directory_name)

            blob = bucket.blob(file.filename)
            blob.upload_from_file(file)
        except ValueError as exc:
            error_message = str(exc)
    return redirect('/')

# Route for download
@app.route('/download_file/<string:filename>', methods=['POST'])
def downloadFile(filename):
    id_token = request.cookies.get("token")
    error_message = None
    claims = None
    times = None
    user_info = None
    file_bytes = None
    if id_token:
        try:
            claims = google.oauth2.id_token.verify_firebase_token(id_token,firebase_request_adapter)
        except ValueError as exc:
            error_message = str(exc)
    return Response(downloadBlob(filename), mimetype='application/octet-stream')

# Route for displaying the main page (root)
@app.route('/')
def root():
    id_token = request.cookies.get("token")
    error_message = None
    claims = None
    times = None
    user_info = None
    file_list = []
    directory_list = []
    if id_token:
        try:
            claims = google.oauth2.id_token.verify_firebase_token(id_token,
            firebase_request_adapter)
            user_info = retrieveUserInfo(claims)
            if user_info == None:
                createUserInfo(claims)
                user_info = retrieveUserInfo(claims)
            blob_list = blobList(None)
            for i in blob_list:
                if i.name[len(i.name) - 1] == '/':
                    directory_list.append(i)
                else:
                    file_list.append(i)
        except ValueError as exc:
            error_message = str(exc)
    return render_template('index.html', user_data=claims, error_message=error_message,
user_info=user_info, file_list=file_list, directory_list=directory_list)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)
